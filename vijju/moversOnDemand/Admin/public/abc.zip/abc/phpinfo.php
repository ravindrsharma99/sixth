<?php
   phpinfo();

?>