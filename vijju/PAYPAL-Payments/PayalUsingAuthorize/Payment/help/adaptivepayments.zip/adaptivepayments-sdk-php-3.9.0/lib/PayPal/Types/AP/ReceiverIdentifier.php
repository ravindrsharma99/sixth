<?php 
namespace PayPal\Types\AP;
use PayPal\Types\Common\AccountIdentifier; 
/**
 * The sender identifier type contains information to identify
 * a PayPal account. 
 */
class ReceiverIdentifier  extends AccountIdentifier  
  {


}
