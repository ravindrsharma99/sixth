<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
<title>PayPal Permissions SDK - Samples Main Page</title>
</head>
<body>
	<center>
		<h4>Permissions SDK Samples Home Page</h4>
		<table>
			<tr>
				<th>Permissions API methods</th>
			</tr>
			<tr>
				<td><a id="RequestPermissions" href="RequestPermissions.php"
					name="RequestPermissions">RequestPermissions</a></td>
			</tr>
			<tr>
				<td><a id="GetAccessToken" href="GetAccessToken.php"
					name="GetAccessToken">GetAccessToken</a></td>
			</tr>
		</table>
	</center>
</body>
</html>