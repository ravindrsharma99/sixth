<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>PayPal Merchant SDK - GetPalDetails</title>
<link rel="stylesheet" href="../Common/sdk.css"/>
</head>
<body>

	<div id="header">
		<h3>GetPalDetails</h3>
		<div id="apidetails">GetPalDetails API operation gets the information
			about the partner of the requested Merchant.</div>
	</div>
	<form method="POST" action="GetPalDetails.php">
		<div id="request_form">
			<div class="submit">
				<input type="submit" name="GetPalDetailsBtn" value="GetPalDetails" /><br />
			</div>
			<a href="../index.php">Home</a>
		</div>
	</form>


</body>
</html>
