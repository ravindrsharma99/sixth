<?php 
namespace PayPal\EnhancedDataTypes;
use PayPal\Core\PPXmlMessage;
/**
 * 
 */
class EnhancedCompleteRecoupRequestDetailsType  
   extends PPXmlMessage{


    
}
