<?php 
namespace PayPal\PayPalAPI;
use PayPal\EBLBaseComponents\AbstractRequestType; 
/**
 * 
 */
class UpdateRecurringPaymentsProfileRequestType  extends AbstractRequestType  
  {

	/**
	 * 
	 * @access public
	 
	 * @namespace ebl
	 
	 	 	 	 
	 * @var PayPal\EBLBaseComponents\UpdateRecurringPaymentsProfileRequestDetailsType	 
	 */ 
	public $UpdateRecurringPaymentsProfileRequestDetails;


    
}
