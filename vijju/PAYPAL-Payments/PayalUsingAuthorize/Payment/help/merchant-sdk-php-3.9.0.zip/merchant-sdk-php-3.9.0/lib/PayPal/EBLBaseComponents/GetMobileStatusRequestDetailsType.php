<?php 
namespace PayPal\EBLBaseComponents;
use PayPal\Core\PPXmlMessage;
/**
 * Phone number for status inquiry 
 */
class GetMobileStatusRequestDetailsType  
   extends PPXmlMessage{

	/**
	 * Phone number for status inquiry 
	 * @access public
	 
	 * @namespace ebl
	 
	 	 	 	 
	 * @var PayPal\EBLBaseComponents\PhoneNumberType	 
	 */ 
	public $Phone;


    
}
